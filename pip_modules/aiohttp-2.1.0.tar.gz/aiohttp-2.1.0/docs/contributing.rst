.. _aiohttp-contributing:

.. include:: ../CONTRIBUTING.rst


.. disqus::
  :title: instructions for aiohttp contributors
