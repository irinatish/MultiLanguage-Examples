from .addict import Dict


__title__ = 'addict'
__version__ = '2.1.1'
__author__ = 'Mats Julian Olsen'
__license__ = 'MIT'
__copyright__ = 'Copyright 2014, 2015, 2016 Mats Julian Olsen'
__all__ = ['Dict']
