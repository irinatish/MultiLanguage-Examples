"""Utilities for asyncio-friendly file handling."""
from .threadpool import open

__version__ = '0.3.1'

__all__ = (open, )
